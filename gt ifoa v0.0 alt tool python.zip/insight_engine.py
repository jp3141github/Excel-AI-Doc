import openai

# Set your OpenAI API key
openai.api_key = "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"  # Replace with your actual key

import pandas as pd
from typing import Dict, Any
import io
from datetime import datetime
from docx import Document
import os
import openpyxl  # required for Excel reading

# Load API key from environment variable for security
# openai.api_key = os.getenv("OPENAI_API_KEY")

def load_excel_sheet(file_content: bytes, sheet_name: str = None) -> pd.DataFrame:
    """Loads an Excel sheet from a byte stream."""
    try:
        return pd.read_excel(io.BytesIO(file_content), sheet_name=sheet_name)
    except Exception as e:
        raise ValueError(f"Failed to load Excel sheet: {e}")

def generate_summary_stats(df: pd.DataFrame) -> Dict[str, Any]:
    """Generates descriptive statistics and metadata for each column."""
    try:
        desc = df.describe(include='all').to_dict()
        info = {
            col: {
                "dtype": str(df[col].dtype),
                "nulls": int(df[col].isnull().sum()),
                "unique": int(df[col].nunique()),
                "sample_values": df[col].dropna().unique()[:3].tolist()
            }
            for col in df.columns
        }
        return {"stats": desc, "structure": info}
    except Exception as e:
        raise RuntimeError(f"Error generating summary stats: {e}")

def detect_quality_issues(df: pd.DataFrame) -> Dict[str, str]:
    """Detects columns with potential data quality issues."""
    issues = {}
    for col in df.columns:
        null_ratio = df[col].isnull().mean()
        unique_count = df[col].nunique(dropna=True)
        if null_ratio > 0.5:
            issues[col] = "More than 50% missing values"
        elif unique_count == 1:
            issues[col] = "Single unique value (likely static column)"
    return issues

def build_gpt_prompt(stats: dict, structure: dict, issues: dict) -> str:
    """Constructs a prompt for GPT-4 to generate insights."""
    return f"""
You are a highly skilled data analyst. Your job is to:

1. Generate meaningful summaries of the dataset
2. Describe the contents and characteristics of each column
3. Detect patterns and trends across the data
4. Highlight anomalies, inconsistencies, or quality issues
5. Suggest relevant aggregations, filters, or transformations
6. Provide recommendations for how this dataset can be used in reporting or analytics

You are provided with:
- Summary statistics for numerical and categorical columns
- Metadata on column types, nulls, unique values, and sample entries
- Flagged issues such as high nulls or suspiciously constant fields

Use this to produce a structured written report, including:
- Dataset overview
- Column-by-column commentary
- Key patterns and correlations
- Data quality concerns
- Suggestions for improvement

Summary Stats:
{stats}

Column Metadata:
{structure}

Detected Issues:
{issues}
"""

def query_openai_insights(prompt: str) -> str:
    """Queries OpenAI's GPT-4 API for dataset insights."""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message['content']
    except Exception as e:
        raise RuntimeError(f"Failed to query GPT-4: {e}")

def export_report_to_word(prompt: str, stats: dict, structure: dict, issues: dict, insights: str) -> str:
    """Exports the full report to a Word document with a timestamped filename."""
    doc = Document()
    doc.add_heading("Data Insight Report", 0)

    doc.add_heading("Prompt Sent to GPT", level=1)
    doc.add_paragraph(prompt)

    doc.add_heading("Summary Stats", level=1)
    doc.add_paragraph(str(stats))

    doc.add_heading("Column Metadata", level=1)
    doc.add_paragraph(str(structure))

    doc.add_heading("Detected Issues", level=1)
    doc.add_paragraph(str(issues))

    doc.add_heading("GPT-4 Insights", level=1)
    doc.add_paragraph(insights)

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_path = f"insight_report_{timestamp}.docx"
    doc.save(file_path)
    return file_path
