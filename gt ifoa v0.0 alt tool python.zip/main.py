import os
from insight_engine import (
    load_excel_sheet, generate_summary_stats,
    detect_quality_issues, build_gpt_prompt,
    query_openai_insights, export_report_to_word
)

# === CONFIGURATION ===
# Set working directory
os.chdir(r"C:\Users\jayja\Downloads\excel_audit_tool")

# Set your Excel file path and sheet
file_path = "sample_claims.xlsx"
sheet_name = "Sheet1"

# === EXECUTION ===
# Load Excel content
with open(file_path, "rb") as f:
    content = f.read()

# Process dataset
df = load_excel_sheet(content, sheet_name=sheet_name)
stats_info = generate_summary_stats(df)
issues = detect_quality_issues(df)
prompt = build_gpt_prompt(stats_info["stats"], stats_info["structure"], issues)
insights = query_openai_insights(prompt)

# Export report
doc_path = export_report_to_word(prompt, stats_info["stats"], stats_info["structure"], issues, insights)

# Output result
print("\n✅ GPT-4 Insights Generated and Report Saved!")
print(f"📄 File saved at: {doc_path}")
